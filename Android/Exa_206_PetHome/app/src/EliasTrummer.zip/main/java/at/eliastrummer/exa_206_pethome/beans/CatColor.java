package at.eliastrummer.exa_206_pethome.beans;

public enum CatColor {

    BLACK,
    WHITE,
    CREAM,
    RED,
    CINNAMON,
    FAWN,
    CHOCOLATE,
    APRICOT,
    AMBER;

}
