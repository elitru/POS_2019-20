package at.eliastrummer.exa_206_pethome.beans;

public enum Size {

    SMALL,
    MEDIUM,
    LARGE;
}
