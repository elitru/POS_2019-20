package at.EliasTrummer.ContactsApp.utils;

import at.EliasTrummer.ContactsApp.bl.Contact;

public class Utils {
    public static Contact currentContact;
}
