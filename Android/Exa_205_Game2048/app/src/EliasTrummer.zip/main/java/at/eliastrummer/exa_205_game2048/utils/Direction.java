package at.eliastrummer.exa_205_game2048.utils;

public enum Direction {
    TOP,
    RIGHT,
    BOTTOM,
    LEFT
}
